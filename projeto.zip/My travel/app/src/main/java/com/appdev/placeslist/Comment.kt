package com.appdev.placeslist

data class Comment(
    val idPlace: Int,
    val idUser: Int,
    val comment: String,
    val userName: String
)




